package com.mockinterview.backend.service;

public class InterviewService {
    
}
